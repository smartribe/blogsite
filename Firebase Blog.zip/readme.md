We are creating a blog website using firebase and below is the structure

Firebase Blog
index.html #list all the blog post we add
post.html #Show the details of a clicked blog
admin.html #Admin page for adding,editting and deleting blogs
styles.css # to style the website
#script.js #handle the firebase logic

Blog content fields
title
content
date.
image
